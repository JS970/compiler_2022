#include "hw_table.h"

#define MAXTABLE 100		
#define MAXNAME  31		
#define MAXLEVEL 5	

void blockBegin(int firstAddr)	
{
}

void blockEnd()				
{
}

int enterTfunc(char *id, int v)		
{
}

int enterTpar(char *id)				
{
}

int enterTvar(char *id)			
{
}

int enterTconst(char *id, int v)		
{
}

int searchT(char *id, KindT k)		
{
}

void printTable() 
{
}
